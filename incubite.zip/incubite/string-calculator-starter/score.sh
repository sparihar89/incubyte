./gradlew test
